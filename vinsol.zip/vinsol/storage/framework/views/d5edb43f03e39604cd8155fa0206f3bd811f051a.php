<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <style>
        body {
          font-family: Arial;
        }
        .coupon {
          border: 5px dotted #bbb;
          width: 80%;
          border-radius: 15px;
          margin: 0 auto;
          max-width: 600px;
        }

        .container {
          padding: 2px 16px;
          background-color: #f1f1f1;
        }

        .promo {
          background: #ccc;
          padding: 3px;
        }

        .expire {
          color: red;
        }
        /* navbar css starts here*/
        .navbar {
          width: 100%;
          background-color: #555;
          overflow: auto;
          margin-bottom: 10px;
        }

        .navbar a {
          float: left;
          padding: 12px;
          color: white;
          text-decoration: none;
          font-size: 17px;
        }

        .navbar a:hover {
          background-color: #000;
        }

        .active {
          background-color: #04AA6D;
        }

        @media  screen and (max-width: 500px) {
          .navbar a {
            float: none;
            display: block;
          }
        }
        .button {
          background-color: #4CAF50; /* Green */
          border: none;
          color: white;
          padding: 10px 28px;
          text-align: center;
          text-decoration: none;
          display: inline-block;
          font-size: 14px;
        }
        .big
        {
          font-size: 28px;
        }
    </style>
  </head>
<body>
  <div class="navbar">
    <a class="active" href="#"><i class="fa fa-fw fa-home"></i>Hello <?php echo e(Session::get('name')); ?></a> 
    <a href="#"><i class="fa fa-fw fa-search"></i> Deal of the day is here</a> 
  </div>
  <?php if(isset($product) && !empty($product)): ?>
  <div class="coupon">
    <div class="container">
      <?php if(Session::has('buy_status')): ?>
      <div style="color: red;">
        <?php echo e(Session::get('buy_status')); ?>

      </div>
      <?php endif; ?>
      <h3><?php echo e($product->title); ?></h3>
    </div>
    <img src=<?php echo e(Storage::url($product->image)); ?> alt="Avatar" style="width:100%;">
    <div class="container" style="background-color:white">
      <h2><b><?php echo e($product->discount); ?>% OFF ON YOUR PURCHASE</b></h2> 
      <h4><p>Price : <strike><?php echo e($product->price); ?></strike> <span class="big"><?php echo e($product->discounted_price); ?></span></p></h4>
      <p><span class="promo">
        <?php if($product->quantity>0): ?>
          Only <?php echo e($product->quantity); ?> product left
        <?php else: ?>
          Product Out of stock
        <?php endif; ?>
      </span></p>
      <p><?php echo e($product->description); ?></p>
    </div>
    <div class="container">
      <form method="POST" action="buy" onsubmit="return confirm('Do you want to submit?')">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" id="product_id">
        <input type="hidden" name="user_id" value="<?php echo e(Session::get('user_id')); ?>" id="user_id">
        <?php if($product->quantity>0): ?>
           <button class="button" type="submit">Buy Now</button>
        <?php endif; ?> 
      </form>
      <!-- printed date next to publish date -->
      <p class="expire">Expires: <?php echo e(date("d-M-Y", strtotime("$product->publish_date +1 days"))); ?> at 10AM</p>
    </div>
  </div>
  <?php else: ?>
    <div>
      <p>No deals found for the day</p>
    </div>
  <?php endif; ?>
  </body>
</html> 

<?php /**PATH F:\vinsol\resources\views/home.blade.php ENDPATH**/ ?>