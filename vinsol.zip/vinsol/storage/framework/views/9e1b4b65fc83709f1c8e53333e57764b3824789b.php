<!DOCTYPE html>
<html>
	<head>
		<title>Admin Panel</title>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		<!-- for datepicker -->
		<link href=
		'https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/ui-lightness/jquery-ui.css'
		          rel='stylesheet'>     
	    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js" ></script> -->
	    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" >
	    </script>
	</head>
	<body>
		<div class="container">
			<h3>Publish deal of the day</h3>
			<?php if(Session::has('save_product_status')): ?>
			<div class="alert alert-success" role="alert">
			  Product saved!
			</div>
			<?php endif; ?>
			<form method="POST" action="save_product" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Title</label>
			    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="It should be unique." name="title" value="<?php echo e(old('title')); ?>">
			  	<?php if($errors->has('title')): ?>
			    	<span style="color: red;"><?php echo e($errors->first('title')); ?></span>
			    <?php endif; ?>
			  </div>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Description</label>
			    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" name="description" value="<?php echo e(old('description')); ?>">
			    <?php if($errors->has('description')): ?>
			    	<span style="color: red;"><?php echo e($errors->first('description')); ?></span>
			    <?php endif; ?>
			  </div>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Price</label>
			    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" name="price" value="<?php echo e(old('price')); ?>">
			    <?php if($errors->has('price')): ?>
			    	<span style="color: red;"><?php echo e($errors->first('price')); ?></span>
			    <?php endif; ?>
			  </div>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Discounted Price</label>
			    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" name="discounted_price" value="<?php echo e(old('discounted_price')); ?>">
			    <?php if($errors->has('discounted_price')): ?>
			    	<span style="color: red;"><?php echo e($errors->first('discounted_price')); ?></span>
			    <?php endif; ?>
			  </div>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Quantity</label>
			    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" name="quantity" value="<?php echo e(old('quantity')); ?>">
			    <?php if($errors->has('quantity')): ?>
			    	<span style="color: red;"><?php echo e($errors->first('quantity')); ?></span>
			    <?php endif; ?>
			  </div>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Publish Date</label>
			    <input placeholder="Should be a future date" id="publish_date" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" name="publish_date" value="<?php echo e(old('publish_date')); ?>">
			    <?php if($errors->has('publish_date')): ?>
			    	<span style="color: red;"><?php echo e($errors->first('publish_date')); ?></span>
			    <?php endif; ?>
			  </div>
			  <div class="form-group">
			    <input type="file" class="custom-file-input" id="validatedCustomFile" value="<?php echo e(old('image')); ?>" name="image">
			    <?php if($errors->has('image')): ?>
			    	<span style="color: red;"><?php echo e($errors->first('image')); ?></span>
			    <?php endif; ?>
			  </div>
			  <button type="submit" class="btn btn-primary">Save</button>
			</form>
		</div>
		<script type="text/javascript">
			$(function() {
	                $( "#publish_date" ).datepicker({dateFormat: 'yy-mm-dd'});        
	        });
		</script>
	</body>
</html><?php /**PATH F:\vinsol\resources\views/admin.blade.php ENDPATH**/ ?>