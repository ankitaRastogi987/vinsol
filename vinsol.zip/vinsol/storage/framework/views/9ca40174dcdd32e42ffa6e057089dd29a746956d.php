<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    body {
      font-family: Arial;
    }

    .coupon {
      border: 5px dotted #bbb;
      width: 80%;
      border-radius: 15px;
      margin: 0 auto;
      max-width: 600px;
    }

    .container {
      padding: 2px 16px;
      background-color: #f1f1f1;
    }

    .promo {
      background: #ccc;
      padding: 3px;
    }

    .expire {
      color: red;
    }
    </style>
  </head>
  <body>
    <!-- we can also login by uncommenting this form -->
    <!-- <form action="home">
      <input type="text" name="id">
      <input type="submit" value="Login">
    </form> -->
    <div class="coupon">
      <div class="container">
        <h3>Please Login to see Deal of the day</h3>
      </div>
      <img src=<?php echo e(URL::asset("img/sale.jpg")); ?> alt="Avatar" style="width:100%;">
      <div class="container" style="background-color:white">
        <h2><b>Get upto 5% OFF ON YOUR PURCHASE</b></h2> 
        <p>Lorem ipsum dolor sit amet, et nam pertinax gloriatur. Sea te minim soleat senserit, ex quo luptatum tacimates voluptatum, salutandi delicatissimi eam ea. In sed nullam laboramus appellantur, mei ei omnis dolorem mnesarchum.</p>
      </div>
      <div class="container">
        <p>Lorem ipsum dolor sit amet, et nam <span class="promo">BOH232</span></p>
        <p class="expire">Lorem ipsum dolor</p>
      </div>
    </div>
  </body>
</html> 
<?php /**PATH F:\vinsol\resources\views/index.blade.php ENDPATH**/ ?>