<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Product;
use App\Models\Shopping;
use Carbon\Carbon;

class UserController extends Controller
{
    //
    function index()
    {
    	return view('index');
    }
    function home(Request $request)
    { 
        if(isset($request->id) && $request->id!='')
        {
            $user=User::where('id', '=', $request->id)->first();
            if(isset($user) && !empty($user))
            {
                $request->session()->put('name',$user->name);
                $request->session()->put('email',$user->email);
                $request->session()->put('user_id',$request->id);
                
                // before 10AM we'll show one day's before deal
                $currentTime = Carbon::now();
                if (date('H') < 10)
                {
                    $product = Product::where('publish_date', '=',$currentTime->addDays(-1)->toDateString())->first();
                }
                // otherwise we'll show today's deal
                else if(date('H') >= 10)
                {
                    $product = Product::where('publish_date', '=',date('Y-m-d'))->first();
                }
               
                // check if we have deal of the day or not
                if(isset($product) && !empty($product))
                {
                    // check for upto 5% discount
                    $getDiscount=Shopping::where('user_id', '=', $request->id)->count();
                    if($getDiscount<=5)
                        $product->discount=$getDiscount;
                    else
                        $product->discount=5;

                    $actual_price=$product->discounted_price;
                    $extra_discount=$product->discount;
                    $product->discounted_price=round($actual_price-($actual_price*$extra_discount/100));
                    // dd($product->discounted_price);
                    return view('home',compact('product',$product));
                }
                else
                {
                    return view('home');
                }
            }
        }
    	return redirect('/')->with('login_error',"Invalid user!");
    }
    function admin(Request $request)
    {
    	if(isset($request->id) && $request->id!='')
        {
            return view('admin');
        }
        return redirect('/');
    }

}
