<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ModelUser;
use App\Models\Product;
class ProductController extends Controller
{
    //
    function save_product(Request $request)
    {
    	$id=1; // hard-coded Admin id As per instructions given in task
		$request->validate([
    			'title'=>'required|unique:products',
    		    'description'=>'required',
                'price'=>'required|numeric|min:1',
                'discounted_price'=>'required|numeric|lte:price|min:1',
                'quantity'=>'required|numeric|min:1',
                'publish_date'=>'unique:products|required|after_or_equal:' . date('Y-m-d') . '|date_format:Y-m-d',
                'image'=>'required|file|mimes:jpeg,bmp,png,jpg',
    	]);
		$image=$request->file('image')->store('public');
    	Product::create([
    			'title'=>$request->get('title'),
    		    'description'=>$request->get('description'),
                'price'=>$request->get('price'),
                'discounted_price'=>$request->get('discounted_price'),
                'quantity'=>$request->get('quantity'),
                'publish_date'=>$request->publish_date,
                'image'=>$image,
    	]);
        return redirect('/admin?id=1')->with('save_product_status','Product saved Successfully');
    }
}
