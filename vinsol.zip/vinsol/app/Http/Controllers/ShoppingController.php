<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ModelUser;
use App\Models\Product;
use App\Models\Shopping;
use DB;
class ShoppingController extends Controller
{
    //
    function buy(Request $request)
    {
        // check quantity
        $chkQuantity=Product::where('id',$request->get('product_id'))->first()->quantity;
        //if its 0 then user cann't buy
        if($chkQuantity>0) 
        {
            $alreadyBuyed=Shopping::where('user_id',$request->get('user_id'))
                    ->where('product_id',$request->get('product_id'))
                    ->first();
            // can buy only single time
            if(isset($alreadyBuyed) && !empty($alreadyBuyed)) 
            {
                return redirect("/home?id=".$request->get('user_id'))->with("buy_status","You can not buy same deal again");
            }
            // checking quantity
            Product::where('id',$request->get('product_id'))
                ->update([
                    'quantity'=> DB::raw('quantity-1'),
            ]);
            // connecting user with product
            Shopping::create([
                    'user_id'=>$request->get('user_id'),
                    'product_id'=>$request->get('product_id'),
            ]);
            return redirect("/home?id=".$request->get('user_id'))->with("buy_status","Product buy successfully");
        }
        else
        {
            return redirect("/home?id=".$request->get('user_id'))->with("buy_status","Sorry! Product out of stock");
        }
        // return redirect("/home?id=$request->get('user_id')");
    }
}
