<!DOCTYPE html>
<html>
	<head>
		<title>Admin Panel</title>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		<!-- for datepicker -->
		<link href=
		'https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/ui-lightness/jquery-ui.css'
		          rel='stylesheet'>     
	    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js" ></script> -->
	    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" >
	    </script>
	</head>
	<body>
		<div class="container">
			<h3>Publish deal of the day</h3>
			@if(Session::has('save_product_status'))
			<div class="alert alert-success" role="alert">
			  Product saved!
			</div>
			@endif
			<form method="POST" action="save_product" enctype="multipart/form-data">
				@CSRF
			  <div class="form-group">
			    <label for="exampleInputEmail1">Title</label>
			    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="It should be unique." name="title" value="{{old('title')}}">
			  	@if($errors->has('title'))
			    	<span style="color: red;">{{ $errors->first('title') }}</span>
			    @endif
			  </div>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Description</label>
			    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" name="description" value="{{old('description')}}">
			    @if($errors->has('description'))
			    	<span style="color: red;">{{ $errors->first('description') }}</span>
			    @endif
			  </div>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Price</label>
			    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" name="price" value="{{old('price')}}">
			    @if($errors->has('price'))
			    	<span style="color: red;">{{ $errors->first('price') }}</span>
			    @endif
			  </div>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Discounted Price</label>
			    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" name="discounted_price" value="{{old('discounted_price')}}">
			    @if($errors->has('discounted_price'))
			    	<span style="color: red;">{{ $errors->first('discounted_price') }}</span>
			    @endif
			  </div>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Quantity</label>
			    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" name="quantity" value="{{old('quantity')}}">
			    @if($errors->has('quantity'))
			    	<span style="color: red;">{{ $errors->first('quantity') }}</span>
			    @endif
			  </div>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Publish Date</label>
			    <input placeholder="Should be a future date" id="publish_date" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" name="publish_date" value="{{old('publish_date')}}">
			    @if($errors->has('publish_date'))
			    	<span style="color: red;">{{ $errors->first('publish_date') }}</span>
			    @endif
			  </div>
			  <div class="form-group">
			    <input type="file" class="custom-file-input" id="validatedCustomFile" value="{{old('image')}}" name="image">
			    @if($errors->has('image'))
			    	<span style="color: red;">{{ $errors->first('image') }}</span>
			    @endif
			  </div>
			  <button type="submit" class="btn btn-primary">Save</button>
			</form>
		</div>
		<script type="text/javascript">
			$(function() {
	                $( "#publish_date" ).datepicker({dateFormat: 'yy-mm-dd'});        
	        });
		</script>
	</body>
</html>